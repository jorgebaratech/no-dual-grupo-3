
public class EquipoClasificacion {
	
	private Equipo equipo;
	private int jugados = 0;
	private int victorias = 0;
	private int derrotas = 0;
	private int empates = 0;
	private int sumarGoles = 0;
	private int restarGoles = 0;
	private int difGoles = 0;
	private int puntos = 0;
	
	
	public Equipo getEquipo() {
		return equipo;
	}
	public void setEquipo(Equipo equipo) {
		this.equipo = equipo;
	}
	public int getVictorias() {
		return victorias;
	}
	public void setVictorias(int victorias) {
		this.victorias = victorias;
	}
	public int getDerrotas() {
		return derrotas;
	}
	public void setDerrotas(int derrotas) {
		this.derrotas = derrotas;
	}
	public int getEmpates() {
		return empates;
	}
	public void setEmpates(int empates) {
		this.empates = empates;
	}
	public void setrestarGoles(int restarGoles) {
		this.setRestarGoles(restarGoles);
	}
	public int getSumarGoles() {
		return sumarGoles;
	}
	public void setSumarGoles(int sumarGoles) {
		this.sumarGoles = sumarGoles;
	}
	public int getRestarGoles() {
		return restarGoles;
	}
	public void setRestarGoles(int restarGoles) {
		this.restarGoles = restarGoles;
	}
	public int getDifGoles() {
		return difGoles;
	}
	public void setDifGoles(int difGoles) {
		this.difGoles = difGoles;
	}
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}	
	public void addGolesFavor(int goles)
	{
		this.sumarGoles+=goles;
		this.difGoles+=goles;
	}	
	public void addGolesContra (int goles)
	{
		this.restarGoles+=goles;
		this.difGoles+=goles;
	}	
	public void addPartidoGanado()
	{
		this.victorias++;
		this.puntos+=3;
	}
	public void addPartidoPerdido()
	{
		this.derrotas--;
	}
	public void addPartidoEmpatado()
	{
		this.setJugados(this.getJugados() + 1);
		this.empates++;
		this.puntos+=1;
	}
	public int getJugados() {
		return jugados;
	}
	public void setJugados(int jugados) {
		this.jugados = jugados;
	}

	
	@Override
	public String toString()
	{
		return equipo.getNombre() + "\t\t\t" + jugados + "\t" + victorias
		+ "\t" + derrotas + "\t" + empates + "\t" + sumarGoles + "\t"
		+ restarGoles + "\t" + difGoles + "\t" + puntos + "\n" + 
		"------------------------------------------------------------------------------------------------------------------" 
		+ "\n";
		
	}



}
