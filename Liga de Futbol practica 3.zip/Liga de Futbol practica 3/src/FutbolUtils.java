import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FutbolUtils {
	

	       public void guardarEquipo (String nombreArchivo, Equipo equipo) {
	    	Equipo equipo1=new Equipo();
	    	
	    	   equipo1.setNombre(null);
	    	   equipo1.setClub(null);
	    	   equipo1.setEntrenador(null);
	    	   equipo1.setJugadores(null);
	    	   equipo1.setEquipacionCasa(null);
	    	   equipo1.setEquipacionFuera(null);
	    	 
	    	   
	    	   
	    	   
	    	   
	    	 String nombreEquipo=equipo1.getNombre()+".txt";
	    	 
	    	

	    		 try {
	    			 FileWriter Fileequipo=new FileWriter(nombreArchivo);	
	    		        BufferedWriter bufferedEquipo=new BufferedWriter(Fileequipo);
	    	       
	    	        }
	    	        catch(IOException e){
	    	        	System.out.println("Esto ha petao.");
	    	            e.printStackTrace();
	    	        }
	    	        System.out.println("Fin del proceso de escritura jugador");
	    	   
	    	   
	    	   
	              //Este m�todo recibe unequipo y un nombre de archivo y guarda el equipo

	             //enun archivo con ese nombre

	       }

	      

	       public Equipo cargarEquipo (String nombreArchivo) {
			return null;

	              //Este m�todo recibe unnombre de Archivo y devuelve un equipo

	       }

	      

	       public Equipo ordenarEquipo (Equipo equipo) {
			return equipo;

	              //Este m�todo recibe un Equipo y ordena sus jugadores por apellidos y en

	             //caso de igualdad de apellidos por nombre

	       }

	      

	       //A�ade las clases que consideres necesarias

	 
	       private static Jugador[] crearJugadores(int numeroJugadores, int edad, Equipo equipo) {
	   		//Listado de Nombres, Apellidos, Posiciones para generador random
	   		String[] nombres = {"Antonio", "Pepito", "Alejandra", "Ismael", "Hugo", "Oliver","Kalesi",
	   				"Ingrid","Astrid","Indira","Jenny","Jessi","Vane","Joel","Bruno",
	   				"Sasha","Billie","Masha","Pingu"};
	   		String[] apellidos = {"Messi", "Vinicius", "Cristiano", "Ronaldo", "Piqu�","Bale (lesionado)",
	   				"Amunike","N'kono","Butrague�o","Sanch�s","Neymar","Batistuta","Maradona",
	   				"Pel�","Beckenbauer"};
	   		String[] posiciones = {"Portero/a","Defensa","Centrocampista","Delantero/a"};

	   		//Estructura de Array de Jugadores
	   		Jugador[] jugadores = new Jugador[numeroJugadores];

	   		for (int i=0; i < numeroJugadores; i++) {
	   			//Crear un Jugador
	   			Jugador jug = new Jugador();
	   			//Nombre
	   			int numero = (int) Math.floor(Math.random()*nombres.length);
	   			String nombre = nombres[numero];
	   			jug.setNombre(nombre);

	   			//Apellidos
	   			numero = (int) Math.floor(Math.random()*apellidos.length);
	   			String apellido1 = apellidos[numero];
	   			numero = (int) Math.floor(Math.random()*apellidos.length);
	   			String apellido2 = apellidos[numero];
	   			jug.setApellidos(apellido1+" "+apellido2);

	   			//Posici�n
	   			numero = (int) Math.floor(Math.random()*posiciones.length);
	   			String posicion = posiciones[numero];
	   			jug.setPosicion(posicion);

	   			//Edad
	   			jug.setEdad(edad);

	   			//Dorsal
	   			jug.setDorsal(i+1);

	   			//Equipo
	   			jug.setEquipo(equipo);

	   			jugadores[i]=jug;

	   			//Imprime jugadores de los equipos creados anteriormente.
	   			//System.out.println(jug);
	   		}

	   		return jugadores;
	   	}

	   	private static Equipo[] crearEquipos(int numeroEquipos,int edad) {

	   		String [] nombreBarrios = {"El Candado", "Huelin", "Tiro Pich�n", "Rinc�n de la Victoria", "La Rosaleda", "Torremolinos",
	   				"Velez M�laga","Cerrado de Calderon", "El Puerto de la Torre", "Bresca", "Mezquitilla", "Teatinos", "Motril",
	   				"Centro","Santa Paula", "El Palo", "Los Corazones", "Las Delicias", "Recogidas","Nueva M�laga", "Casas Blancas",
	   				"La Palmilla","Los Asperones","Campanillas","La Corta"};
	   		String [] mascotas = {"Los Pollos", "Los Araclanes", "Los Limones", "Los Delfines", "Los Chanquetes", "Los Gatitos",
	   				"Los Boquerones", "Los Toros", "Los Perritos", "Los Halcones", "Los Ornitorrincos", "Los Caracoles",
	   				"Los Palomos Cojos", "Los Heterosaurios", "Las Tortugas Ninjas", "Los Pintarrojas"};

	   		Equipo [] listaEquipos= new Equipo[numeroEquipos];

	   		for (int i=0; i<numeroEquipos; i++) {
	   			//Creamos Equipo
	   			Equipo equipo = new Equipo();
	   			
	   			//Elegimos random un nombre y una mascota de las listas respectivas.
	   			int numero = (int) Math.floor(Math.random()*nombreBarrios.length);
	   			String barrio= nombreBarrios[numero];
	   			numero = (int) Math.floor(Math.random()*mascotas.length);
	   			String mascota= mascotas[numero];


	   			//Definimos el club en base al nombre del barrio
	   			equipo.setClub(barrio+" F.C.");

	   			//Las pegamos con un "de" en medio
	   			String nombre;
	   			if (barrio.startsWith("El ")) 
	   			{
	   				barrio = barrio.substring(3);
	   				nombre = mascota + " del "+ barrio;
	   			}
	   			else 
	   			{
	   				nombre = mascota + " de "+ barrio;
	   			}

	   			equipo.setNombre(nombre);


	   		


	   			//Meter los jugadores
	   			int numeroJugadores=(int) Math.floor(Math.random()*7)+15;
	   			Jugador[] jugadores = crearJugadores(numeroJugadores,edad,equipo);
	   			equipo.setJugadores(jugadores);

	   			//Meter el equipo en el array de equipos


	   			listaEquipos[i] = equipo;
	   			//System.out.println("*************************************************************************************************************");
	   		}
	   		return listaEquipos;

	   	}

	   	

	   	
	       
	       
	   	
	
	   	

}

