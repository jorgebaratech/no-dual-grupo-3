
public class Calendario {
	public Jornada[] jornadas;
	
	public Calendario() {}
	
	public void setJornadas(Jornada[] jornadas) {
		this.jornadas = jornadas;
	}
	
	public Jornada[] getJornadas() {
		return this.jornadas;
	}
}
