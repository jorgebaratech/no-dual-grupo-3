public class FilaClasificacion {

    private Equipo equipo;
    private int jugados=0;
    private int ganados=0;
    private int empatados=0;
    private int perdidos=0;
    private int gFavor=0;
    private int gContra=0;
    private int difGoles=0;
    private int puntos=0;

    public String toString() {
        String cadena= equipo.getNombre();
        int longitud = cadena.length();
        int espacios = 53-longitud;
        for (int i=0; i<espacios;i++) {
            cadena+=" ";
        }
        cadena+="\t"+getJugados()+"\t\t"+getGanados()+"\t\t"+getEmpatados()+"\t\t"+getPerdidos()+"\t\t"+getgFavor()+"\t\t"+getgContra()+"\t\t"+getDifGoles()+"\t\t"+getPuntos()+"\t\n"+"\n";
        return cadena;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public int getJugados() {
        return jugados;
    }

    public void setJugados(int jugados) {
        this.jugados = jugados;
    }

    public int getGanados() {
        return ganados;
    }

    public int getEmpatados() {
        return empatados;
    }

    public int getPerdidos() {
        return perdidos;
    }

    public int getgFavor() {
        return gFavor;
    }

    public int getgContra() {
        return gContra;
    }

    public int getDifGoles() {
        return difGoles;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setGanados(int ganados) {
        this.ganados = ganados;
    }

    public void setEmpatados(int empatados) {
        this.empatados = empatados;
    }

    public void setPerdidos(int perdidos) {
        this.perdidos = perdidos;
    }

    public void setgFavor(int gFavor) {
        this.gFavor = gFavor;
    }

    public void setgContra(int gContra) {
        this.gContra = gContra;
    }

    public void setDifGoles(int gFavor, int gContra) {
        this.difGoles = (gFavor-gContra);
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public void añadirClasificacion(){
        setEquipo(equipo);
        setEmpatados(empatados);
        setPuntos(puntos);
        setGanados(ganados);
        setPerdidos(perdidos);
        setgFavor(gFavor);
        setgContra(gContra);
        setDifGoles(gFavor, gContra);
        setJugados(jugados);
    }

    public void addVictoria(Equipo equipo, int resultadoF, int resultadoC, int numero) {
        jugados++;
        ganados++;
        puntos+=numero;
        gFavor+=resultadoF;
        gContra+=resultadoC;
    }

    public void addDerrota(Equipo equipo, int resultadoF, int resultadoC, int numero) {
        jugados++;
        perdidos++;
        puntos+=numero;
        gFavor+=resultadoF;
        gContra+=resultadoC;
    }

    public void addEmpate(Equipo equipo, int resultadoF, int resultadoC, int numero){
        jugados++;
        empatados++;
        puntos+=numero;
        gFavor+=resultadoF;
        gContra+=resultadoC;
    }
}
