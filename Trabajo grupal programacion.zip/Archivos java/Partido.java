import java.util.Objects;

public class Partido {

    Equipo equipo1;
    Equipo equipo2;
    int resultado1=0;
    int resultado2=0;
    Arbitro arbitro;

    public Equipo getEquipo1() {
        return equipo1;
    }
    public void setEquipo1(Equipo equipo1) {
        this.equipo1 = equipo1;
    }
    public Equipo getEquipo2() {
        return equipo2;
    }
    public void setEquipo2(Equipo equipo2) {
        this.equipo2 = equipo2;
    }
    public Arbitro getArbitro() {
        return arbitro;
    }
    public void setArbitro(Arbitro arbitro) {
        this.arbitro = arbitro;
    }
    public int getResultado1() {
        return resultado1;
    }
    public int getResultado2() {
        return resultado2;
    }
    public void setResultado1(int resultado1) {
        this.resultado1 = resultado1;
    }
    public void setResultado2(int resultado2) {
        this.resultado2 = resultado2;
    }
    public void jugarPartido() {
//      Se crean 2 variables y se calcula un valor aleatorio entre 0 y 10 que serán el numero de goles
        int r1 = (int) Math.floor(Math.random()*10);
        int r2 = (int) Math.floor(Math.random()*10);

//      Se guardan
        resultado1=r1;
        resultado2=r2;
    }

    @Override
    public String toString() {
        if (Objects.equals(equipo2.getNombre(), "Descanso")) {
            return equipo1.getNombre() + " - Descanso" + "\n";
        } else if (Objects.equals(equipo1.getNombre(), "Descanso")) {
            return equipo2.getNombre() + " - Descanso" + "\n";
        }else {
            return equipo1.getNombre() + " [" + resultado1 + " : "
                    + resultado2 + "] " + equipo2.getNombre()
                    + ", Arbitro: " + arbitro.getApellidos() + "\n";
        }
    }
}