import java.util.HashMap;

public class Jornada {
    private Arbitro [] arbitros;
    private Equipo [] equipos;
    private int numeroPartidos;
    private Partido [] partidos;
    private boolean terminada=false;


    public boolean isTerminada() {
        return terminada;
    }

    public void setTerminada(boolean terminada) {
        this.terminada = terminada;
    }

    public void terminar() {
        this.terminada = true;
    }

    //variables para los calculos
    HashMap<Equipo, Integer> resultados = new HashMap<Equipo, Integer>();

    public Arbitro[] getArbitros() {
        return arbitros;
    }
    public void setArbitros(Arbitro[] arbitros) {
        this.arbitros = arbitros;
    }
    public Equipo[] getEquipos() {
        return equipos;
    }
    public void setEquipos(Equipo[] equipos) {
        this.equipos = equipos;
        this.numeroPartidos=equipos.length/2;
    }
    public int getNumeroPartidos() {
        return numeroPartidos;
    }
    public Partido[] getPartidos() {
        return partidos;
    }
    public void setPartidos(Partido[] partidos) {
        this.partidos = partidos;
    }

    @Override
    public String toString() {
        String cadena=" \n";
        for (int i=0;i<this.partidos.length;i++) {
            cadena+=partidos[i];
        }
        return cadena;
    }

}