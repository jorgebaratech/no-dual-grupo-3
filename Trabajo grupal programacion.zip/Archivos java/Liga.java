import java.util.Arrays;

public class Liga {

    private String nombre;
    private Equipo[] equipos;
    private Calendario calendario;
    private Arbitro[] arbitros;
    private Clasificacion clasificacion;

//	Constructor de liga

    public Liga(String nombre, Equipo [] equipos, Arbitro [] arbitros, Setting ajustes) {
        this.nombre=nombre;
        this.equipos=equipos;
        this.arbitros=arbitros;
        this.calendario=new Calendario(equipos,arbitros);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Equipo[] getEquipos() {
        return equipos;
    }

    public void setEquipos(Equipo[] equipos) {
        this.equipos = equipos;
    }

    public Arbitro[] getArbitros() {
        return arbitros;
    }

    public void setArbitros(Arbitro[] arbitros) {
        this.arbitros = arbitros;
    }

    public Calendario getCalendario() {
        return calendario;
    }
    public Clasificacion getClasificacion() {
        return clasificacion;
    }



    @Override
    public String toString() {
        return "Liga" + "\n" +
                "nombre: '" + nombre + '\'' +
                ", equipos: " + Arrays.toString(equipos) +
                ", arbitros=" + Arrays.toString(arbitros) +
                ", calendario=" + calendario +
                '}';
    }
}