import java.util.Objects;

public class Clasificacion {

    private FilaClasificacion[] clasificacion;
    private Jornada jornadaActual;
    private int numJornada;

    public FilaClasificacion[] crearClasificacion(Equipo[] equipo, Jornada[] jornadas){

        FilaClasificacion[] filaEquipo = new FilaClasificacion[equipo.length];

        for (int i=0; i<filaEquipo.length; i++) {

            FilaClasificacion fila = new FilaClasificacion();
            fila.setEquipo(equipo[i]);
            filaEquipo[i] = fila;
        }
        clasificacion=filaEquipo;
        return clasificacion;
    }

    public void actualizarClasificacion(FilaClasificacion[] fila, Calendario calendario, Setting ajustes, int numeroJornada){
        int numeroEquipos = ajustes.getnEquipos();
        if (numeroEquipos%2!=0) {
            numeroEquipos++;
        }
        FilaClasificacion[] clasificacionActualizada = new FilaClasificacion[numeroEquipos];

        jornadaActual = calendario.getJornadas()[numeroJornada-1];
        this.numJornada=numeroJornada;
        Partido[] partido = jornadaActual.getPartidos();
        int cont=-1;

        for(Partido par: partido){
            cont++;
            boolean esta1=false;
            boolean esta2=false;

            int pVictoria = ajustes.getVictoria();
            int pDerrota = ajustes.getDerrota();
            int pEmpate = ajustes.getEmpate();

            FilaClasificacion filaClasificacion1 = new FilaClasificacion();
            FilaClasificacion filaClasificacion2 = new FilaClasificacion();

            if (!Objects.equals(par.getEquipo2().getNombre(),"Descanso") && !Objects.equals(par.getEquipo1().getNombre(),"Descanso") ) {

                Equipo equipo1 = par.getEquipo1();
                Equipo equipo2 = par.getEquipo2();

                filaClasificacion1.setEquipo(equipo1);
                filaClasificacion2.setEquipo(equipo2);

                for(FilaClasificacion fil : fila){
                    if(!esta1 && par.getEquipo1()==fil.getEquipo()){
                        filaClasificacion1=fil;
                        esta1=true;

                    }else if(!esta2 && par.getEquipo2()==fil.getEquipo()){
                        filaClasificacion2=fil;
                        esta2=true;
                    }
                }

                par.jugarPartido();
                int result1 = par.getResultado1();
                int result2 = par.getResultado2();

                if (result1 > result2) {
                    filaClasificacion1.addVictoria(equipo1, result1, result2, pVictoria);
                    filaClasificacion2.addDerrota(equipo2, result2, result1, pDerrota);
                } else if (result1 < result2) {
                    filaClasificacion1.addDerrota(equipo1, result1, result2, pDerrota);
                    filaClasificacion2.addVictoria(equipo2, result2, result1, pVictoria);
                } else {
                    filaClasificacion1.addEmpate(equipo1, result1, result2, pEmpate);
                    filaClasificacion2.addEmpate(equipo2, result2, result1, pEmpate);
                }
                filaClasificacion1.añadirClasificacion();
                filaClasificacion2.añadirClasificacion();

                clasificacionActualizada[cont] = filaClasificacion1;
                cont++;
                clasificacionActualizada[cont] = filaClasificacion2;
            }else {

                Equipo equipo1 = par.getEquipo1();
                Equipo equipo2 = par.getEquipo2();

                filaClasificacion1.setEquipo(equipo1);
                filaClasificacion2.setEquipo(equipo2);

                for(FilaClasificacion fil : fila){
                    if(!esta1 && par.getEquipo1()==fil.getEquipo()){
                        filaClasificacion1=fil;
                        esta1=true;

                    }else if(!esta2 && par.getEquipo2()==fil.getEquipo()){
                        filaClasificacion2=fil;
                        esta2=true;
                    }
                }

                filaClasificacion1.añadirClasificacion();
                filaClasificacion2.añadirClasificacion();

                clasificacionActualizada[cont] = filaClasificacion1;
                cont++;
                clasificacionActualizada[cont] = filaClasificacion2;
            }
        }
        clasificacion=ordenarClasificacion(clasificacionActualizada);
    }

    public FilaClasificacion[] ordenarClasificacion (FilaClasificacion[] fila) {
        ordenar(fila);
        return fila;
    }

    public void ordenar(FilaClasificacion[] fila) {
        for (int i = 0; i < fila.length - 1; i++) {
            for (int j = 0; j < fila.length - 1; j++) {
                if (vaDebajo(fila[j], fila[j+1])) {
                    FilaClasificacion temp = fila[j + 1];
                    fila[j + 1] = fila[j];
                    fila[j] = temp;
                }
            }
        }
    }

    private boolean vaDebajo(FilaClasificacion equipo1, FilaClasificacion equipo2) {
        if (!Objects.equals(equipo2.getEquipo().getNombre(), "Descanso") || !Objects.equals(equipo1.getEquipo().getNombre(),"Descanso")) {
            if (equipo1.getPuntos() < equipo2.getPuntos()) {//Primer criterio Puntos
                return true;
            } else if (equipo1.getPuntos() > equipo2.getPuntos()) {
                return false;
            } else {//A igualdad de puntos diferencia goles
                if (equipo1.getDifGoles() < equipo2.getDifGoles()) {
                    return true;
                } else if (equipo1.getDifGoles() > equipo2.getDifGoles()) {
                    return false;
                } else {//A igualad de puntos y dif goles. PArtidos ganados
                    if (equipo1.getGanados() < equipo2.getGanados()) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        }else{
            return false;
        }
    }

    @Override
    public String toString(){
        String leyenda= "J: Jugados\n"+
                        "G: Ganados \n"+
                        "P: Perdidos \n"+
                        "GF: Goles a favor \n"+
                        "GC: Goles Contra \n"+
                        "DG: Diferencia de Goles \n"+
                        "Ptos: Puntos"+"\n"+"\n"+
                        "Jornada nº "+numJornada+": \n"+jornadaActual+"\n"+"\n";
        String menu = "Equipo\t\t\t\t\t\t\t\t\t\t\t\t"+"|\tJ\t"+"|\tG\t"+ "|\tE\t" + "|\tP\t" +"|\tGF\t" + "|\tGC\t"+ "|\tDG\t"+"|\tPtos\t"+"\n"+"\n";

        String cadena=leyenda+menu;

        for(FilaClasificacion equi : clasificacion){

            if(!Objects.equals(equi.getEquipo().getNombre(), "Descanso")){
                cadena+=equi;
            }
        }
        return cadena;
    }
}
