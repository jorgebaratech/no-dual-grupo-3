import java.util.Arrays;

public class Calendario {
    private Jornada[] jornadas;

    public Calendario(Equipo [] equipos, Arbitro [] arbitros) {

        int numeroEquipos = equipos.length;
        int numeroPartidos = numeroEquipos / 2;
        int numeroJornadas = (numeroEquipos - 1) * 2;

        Equipo[][] emparejamientos = new Equipo[2][numeroPartidos];

        //Primera columna del array emparejamientos
        for (int i = 0; i< numeroPartidos; i++ ) {
            emparejamientos[0][i]=equipos[i];
        }
        //Segunda columna del array emparejamientos
        for (int j = numeroPartidos -1; j>=0; j--) {
            emparejamientos[1][j]=equipos[numeroEquipos-1-j];
        }

        this.jornadas= new Jornada[numeroJornadas];

        for(int i = 0; i<numeroJornadas/2;i++) {

            Partido[] partidosIda = new Partido[numeroPartidos];
            Partido[] partidosVuelta = new Partido[numeroPartidos];


            for (int j = 0; j < numeroPartidos; j++) {

                partidosIda[j] = new Partido();
                partidosIda[j].setEquipo1(emparejamientos[0][j]);
                partidosIda[j].setEquipo2(emparejamientos[1][j]);
                partidosIda[j].setArbitro(arbitros[j]);

                partidosVuelta[j] = new Partido();
                partidosVuelta[j].setEquipo1(emparejamientos[1][j]);
                partidosVuelta[j].setEquipo2(emparejamientos[0][j]);
                partidosVuelta[j].setArbitro(arbitros[j]);
            }
            jornadas[i] = new Jornada();
            jornadas[i].setPartidos(partidosIda);
            jornadas[jornadas.length - i - 1] = new Jornada();
            jornadas[jornadas.length - i - 1].setPartidos(partidosVuelta);

//          Mover la tabla de emparejamientos para cambiar los enfrentamientos
            Equipo[][] emparejamientosAux = new Equipo[2][numeroPartidos];

            for (int k = 0; k < numeroPartidos; k++) {
                if (k == 0) {
                    emparejamientosAux[0][0] = emparejamientos[0][0];
                }else if (k<numeroPartidos-1) {
                    emparejamientosAux[0][k+1]=emparejamientos[0][k];
                }else {
                    emparejamientosAux[1][k]=emparejamientos[0][k];
                }
            }
            for (int k = 0; k < numeroPartidos; k++) {
                if (k==0) {
                    emparejamientosAux[0][1]=emparejamientos[1][0];
                }else {
                    emparejamientosAux[1][k-1]=emparejamientos[1][k];
                }
            }
            emparejamientos=emparejamientosAux;
        }
    }

    public Jornada[] getJornadas() {
        return jornadas;
    }

    public void setJornadas(Jornada[] jornadas) {
        this.jornadas = jornadas;
    }

    @Override
    public String toString() {
        String cadena="Calendario Oficial: \n";
        for (int i=0;i<this.jornadas.length;i++) {
            cadena+=(i+1)+"ª "+jornadas[i]+"\n";
        }
        return cadena;
    }
}
