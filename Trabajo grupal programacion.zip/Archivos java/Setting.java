import java.util.Scanner;

public class Setting {

    public Setting ajustes;

    private String nombre;
    private int edad;
    private int nEquipos;

    private String fecha;

    private int nJugadores;
    private int[] formacion;

    private int victoria;
    private int empate;
    private int derrota;

    private int diaInicio;

    public static int calculoDia(String mesIn, int diaIn){
        int dia;
        String mes=mesIn.toUpperCase();

        if (mes.equals("ENERO")){
            dia=diaIn;
            return dia;
        }
        if (mes.equals("FEBRERO")){
            dia=diaIn+31;
            return dia;
        }
        if(mes.equals("MARZO")){
            dia=diaIn+59;
            return dia;
        }
        if(mes.equals("ABRIL")){
            dia=diaIn+90;
            return dia;
        }
        if(mes.equals("MAYO")){
            dia=diaIn+120;
            return dia;
        }
        if(mes.equals("JUNIO")){
            dia=diaIn+151;
            return dia;
        }
        if(mes.equals("JULIO")){
            dia=diaIn+181;
            return dia;
        }
        if(mes.equals("AGOSTO")){
            dia=diaIn+211;
            return dia;
        }
        if(mes.equals("SEPTIEMBRE")){
            dia=diaIn+242;
            return dia;
        }
        if(mes.equals("OCTUBRE")){
            dia=diaIn+272;
            return dia;
        }
        if(mes.equals("NOVIEMBRE")){
            dia=diaIn+303;
            return dia;
        }
        if(mes.equals("DICIEMBRE")){
            dia=diaIn+333;
            return dia;
        }
        return 10000001;        //ERROR al inctroducir la fecha
    }

    public static void imprimirMenu(){
        System.out.println("-------------Opciones-----------");
        System.out.println("1. Composicion");
        System.out.println("2. Puntuacion");
        System.out.println("3. Fechas");
    }

    //GETTERS Y SETTERS

    public int getnEquipos() {
        return nEquipos;
    }

    public void setnEquipos(int nEquipos) {
        this.nEquipos = nEquipos;
    }

    public int getnJugadores() {
        return nJugadores;
    }

    public void setnJugadores(int nJugadores) {
        this.nJugadores = nJugadores;
    }

    public void setVictoria(int victoria){
        this.victoria=victoria;
    }

    public int getVictoria() {
        return victoria;
    }

    public void setEmpate(int empate) {
        this.empate = empate;
    }

    public int getEmpate() {
        return empate;
    }

    public void setDerrota(int derrota) {
        this.derrota = derrota;
    }

    public int getDerrota() {
        return derrota;
    }


    public void setFormacion(int[] formacion) {
        this.formacion = formacion;
    }

    public int[] getFormacion() {
        return formacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(int dia, String mes) {
        this.fecha = dia+" de "+" "+mes+" de 2022";
        this.diaInicio=calculoDia(mes,dia);
    }

    //Mostrar por Pantalla
    public String toString(){
        return (" Numero Equipos: "+getnEquipos()+" Numero Jugadores: "+getnJugadores()+"\n"+
                " Puntos: Victoria: "+getVictoria()+" | Empate: "+getEmpate()+" | Derrota: "+getDerrota()+"\n"+
                " Fecha Inicio Temporada: "+getFecha()+"\n"+
                " Formacion (Porteros Defensa CentroCampistas Delantero | Suplentes): ");
    }

    public static void salidaArrayNumNoEnter(int[] lista){
        for (int i = 0; i < lista.length; i++) {

            if(i<lista.length-1) {
                System.out.print(" " + lista[i]);
            }else{
                System.out.print(" | " + lista[i]);
            }
        }
    }
}
