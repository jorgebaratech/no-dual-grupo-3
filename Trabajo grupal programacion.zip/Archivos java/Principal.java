import java.util.Scanner;
import java.util.HashMap;

public class Principal {

    //Liga Año 2022
    public static void main(String[] args){

        Setting ajustes = new Setting();

        predeterminados(ajustes);
        configuracion(ajustes);

        int numEquipos = ajustes.getnEquipos();
        int numJugadores = ajustes.getnJugadores();

        String nombre = ajustes.getNombre();
        int edad = ajustes.getEdad();

        int[] formacion = ajustes.getFormacion();

        Equipo[] equipos = crearEquipos(numEquipos, edad, numJugadores);
        Arbitro [] arbitros = crearArbitros(numEquipos - 1);

        Liga liga = new Liga(nombre, equipos, arbitros, ajustes);
        Calendario calendario=liga.getCalendario();

        menuUso(liga, equipos, calendario, ajustes);

    }

    //Crea e Imprime la clasificacion deseada
    public static void imprimirClasificacionCompleta(Equipo[] equipos, Calendario calendario, Setting ajustes, int jornadaMax){
        Clasificacion clasificacion = new Clasificacion();

        FilaClasificacion[] listaClasificacion = clasificacion.crearClasificacion(equipos, calendario.getJornadas());
        int jornadasTotales=calendario.getJornadas().length;

        if(jornadaMax<=jornadasTotales && jornadaMax>0){
            for (int i=1; i<=jornadaMax; i++){

                clasificacion.actualizarClasificacion(listaClasificacion,calendario,ajustes,i);
                    System.out.println(clasificacion);
            }

        }else{
            System.out.println("Numero jornada no disponible");
        }
    }

    public static void clasificacionParcial(Equipo[] equipos, Calendario calendario, Setting ajustes, int jornadaFinal){
        Clasificacion clasificacionParcial = new Clasificacion();
        FilaClasificacion[] listaClasificacion = clasificacionParcial.crearClasificacion(equipos, calendario.getJornadas());

        HashMap<Integer, String> clasificacionesGuardadas = new HashMap<Integer, String>();

        int jornadasTotales=calendario.getJornadas().length;

        if(jornadaFinal<=jornadasTotales && jornadaFinal>0){
            for (int i=1; i<=jornadaFinal; i++) {

                clasificacionParcial = new Clasificacion();
                String[] clasificacionTemporal = new String[equipos.length];
                clasificacionParcial.actualizarClasificacion(listaClasificacion, calendario, ajustes, i);
                clasificacionTemporal[i]=clasificacionParcial.toString();
                clasificacionesGuardadas.put(i,clasificacionTemporal[i]);
            }

            boolean salir = false;

            while (!salir) {
                System.out.println("¿Que desea hacer?");
                System.out.println("1. Ver una jornada y todas las anteriores");
                System.out.println("2. Ver una jornada");
                System.out.println("3. Salir de este submenu");
                int eleccion = leerNumero();
                int jornadeta;

                if (eleccion == 1 || eleccion == 2) {
                    if (eleccion==1){
                        System.out.println("Indique la jornada en la que desea");
                        jornadeta = leerNumero();
                        for(int k=1; k<=jornadeta; k++){
                            System.out.println(clasificacionesGuardadas.get(k));
                        }
                    }else{
                        System.out.println("Indique la jornada que desea");
                        jornadeta = leerNumero();
                        System.out.println(clasificacionesGuardadas.get(jornadeta));
                    }
                } else if (eleccion == 3) {
                    salir = true;
                }else{
                    System.out.println("Opcion no disponible");
                }
            }

        }else{
            System.out.println("Numero jornada no disponible");
        }
    }

    //Creacion de Objetos

    private static Equipo[] crearEquipos(int numeroEquipos, int edad, int numJugadores) {

        String[] nombreBarrios = {"El Candado", "Huelin", "Tiro Pichón", "Rincón de la Victoria", "La Rosaleda", "Torremolinos",
                "Velez Málaga", "Cerrado de Calderon", "El Puerto de la Torre", "Bresca", "Mezquitilla", "Teatinos", "Motril",
                "Centro", "Santa Paula", "El Palo", "Los Corazones", "Las Delicias", "Recogidas", "Nueva Málaga", "Casas Blancas",
                "La Palmilla", "Los Asperones", "Campanillas", "La Corta"};
        String[] mascotas = {"Los Pollos", "Los Araclanes", "Los Limones", "Los Delfines", "Los Chanquetes", "Los Gatitos",
                "Los Boquerones", "Los Toros", "Los Perritos", "Los Halcones", "Los Ornitorrincos", "Los Caracoles",
                "Los Palomos Cojos", "Los Heterosaurios", "Las Tortugas Ninjas", "Los Pintarrojas"};

        Equipo[] listaEquipos = new Equipo[numeroEquipos];


        for (int i = 0; i < numeroEquipos; i++) {
            //Creamos Equipo
            Equipo equipo = new Equipo();


            //Elegimos random un nombre y una mascota de las listas respectivas.
            int numero = (int) Math.floor(Math.random() * nombreBarrios.length);
            String barrio = nombreBarrios[numero];
            numero = (int) Math.floor(Math.random() * mascotas.length);
            String mascota = mascotas[numero];

            //Definimos el club en base al nombre del barrio
            equipo.setClub(barrio + " F.C.");

            //Las pegamos con un "de" en medio
            String nombre;
            if (barrio.startsWith("El ")) {
                barrio = barrio.substring(3);
                nombre = mascota + " del " + barrio;
            } else {
                nombre = mascota + " de " + barrio;
            }

            equipo.setNombre(nombre);
            //Continuamos con entrenador
            Entrenador entrenador = crearEntrenador(equipo);
            equipo.setEntrenador(entrenador);

            //Meter los jugadores
            int numeroJugadores = numJugadores;
            Jugador[] jugadores = crearJugadores(numeroJugadores, edad, equipo);
            equipo.setJugadores(jugadores);

            //Meter el equipo en el array de equipos

            listaEquipos[i] = equipo;
        }
        if (numeroEquipos%2!=0) {
            Equipo[] nuevoEquipos = new Equipo[numeroEquipos+1];

            System.arraycopy(listaEquipos, 0, nuevoEquipos, 0, numeroEquipos);
            nuevoEquipos[nuevoEquipos.length-1] = new Equipo();
            nuevoEquipos[nuevoEquipos.length-1].setNombre("Descanso");
            listaEquipos=nuevoEquipos;
        }
        return listaEquipos;
    }

    private static Jugador[] crearJugadores(int numeroJugadores, int edad, Equipo equipo) {
        //Listado de Nombres, Apellidos, Posiciones para generador random
        String[] nombres = {"Antonio", "Pepito", "Alejandra", "Ismael", "Hugo", "Oliver", "Kalesi",
                "Ingrid", "Astrid", "Indira", "Jenny", "Jessi", "Vane", "Joel", "Bruno",
                "Sasha", "Billie", "Masha", "Pingu"};
        String[] apellidos = {"Messi", "Vinicius", "Cristiano", "Ronaldo", "Piqué", "Bale (lesionado)",
                "Amunike", "N'kono", "Butragueño", "Sanchís", "Neymar", "Batistuta", "Maradona",
                "Pelé", "Beckenbauer"};
        String[] posiciones = {"Portero/a", "Defensa", "Centrocampista", "Delantero/a"};

        //Estructura de Array de Jugadores
        Jugador[] jugadores = new Jugador[numeroJugadores];

        for (int i = 0; i < numeroJugadores; i++) {
            //Crear un Jugador
            Jugador jug = new Jugador();
            //Nombre
            int numero = (int) Math.floor(Math.random() * nombres.length);
            String nombre = nombres[numero];
            jug.setNombre(nombre);

            //Apellidos
            numero = (int) Math.floor(Math.random() * apellidos.length);
            String apellido1 = apellidos[numero];
            numero = (int) Math.floor(Math.random() * apellidos.length);
            String apellido2 = apellidos[numero];
            jug.setApellidos(apellido1 + " " + apellido2);

            //Posición
            numero = (int) Math.floor(Math.random() * posiciones.length);
            String posicion = posiciones[numero];
            jug.setPosicion(posicion);

            //Edad
            jug.setEdad(edad);

            //Dorsal
            jug.setDorsal(i + 1);

            //Equipo
            jug.setEquipo(equipo);

            jugadores[i] = jug;

        }

        return jugadores;
    }

    private static Arbitro[] crearArbitros(int numArbitros) {
        String[] nombres = {"Antonio", "Pepito", "Alejandra", "Ismael", "Hugo", "Oliver", "Kalesi",
                "Ingrid", "Astrid", "Indira", "Jenny", "Jessi", "Vane", "Joel", "Bruno",
                "Sasha", "Billie", "Masha", "Pingu"};
        String[] apellidos = {"Messi", "Vinicius", "Cristiano", "Ronaldo", "Piqué", "Bale (lesionado)",
                "Amunike", "N'kono", "Butragueño", "Sanchís", "Neymar", "Batistuta", "Maradona",
                "Pelé", "Beckenbauer"};

        //Estructura de Array de Jugadores
        Arbitro[] arbitros = new Arbitro[numArbitros];

        for (int i = 0; i < numArbitros; i++) {
            //Crear un Jugador
            Arbitro arb = new Arbitro();
            //Nombre
            int numero = (int) Math.floor(Math.random() * nombres.length);
            String nombre = nombres[numero];
            arb.setNombre(nombre);

            //Apellidos
            numero = (int) Math.floor(Math.random() * apellidos.length);
            String apellido1 = apellidos[numero];
            numero = (int) Math.floor(Math.random() * apellidos.length);
            String apellido2 = apellidos[numero];
            arb.setApellidos(apellido1 + " " + apellido2);

//			Licencia
            numero = (int) Math.floor(Math.random() * 1000000000);
            arb.setLicencia(numero);

            arbitros[i] = arb;
        }
        return arbitros;
    }

    private static Entrenador crearEntrenador(Equipo equipo) {
        //Listado de Nombres, Apellidos, Posiciones para generador random
        String[] nombres = {"Antonio", "Pepito", "Alejandra", "Ismael", "Hugo", "Oliver", "Kalesi",
                "Ingrid", "Astrid", "Indira", "Jenny", "Jessi", "Vane", "Joel", "Bruno",
                "Sasha", "Billie", "Masha", "Pingu"};
        String[] apellidos = {"Messi", "Vinicius", "Cristiano", "Ronaldo", "Piqué", "Bale (lesionado)",
                "Amunike", "N'kono", "Butragueño", "Sanchís", "Neymar", "Batistuta", "Maradona",
                "Pelé", "Beckenbauer"};
        Entrenador entrenador = new Entrenador();

        //Nombre
        int numero = (int) Math.floor(Math.random() * nombres.length);
        String nombre = nombres[numero];
        entrenador.setNombre(nombre);

        //Apellidos
        numero = (int) Math.floor(Math.random() * apellidos.length);
        String apellido1 = apellidos[numero];
        numero = (int) Math.floor(Math.random() * apellidos.length);
        String apellido2 = apellidos[numero];
        entrenador.setApellidos(apellido1 + " " + apellido2);

        //Equipo
        entrenador.setEquipo(equipo);

        //Edad
        int edad = (int) Math.floor(Math.random() * 47) + 18;
        entrenador.setEdad(edad);
        //Licencia
        int licencia = (int) Math.floor(Math.random() * 100000);
        entrenador.setNumeroLicencia(licencia);

        return entrenador;
    }

    //Configuraciones y ajustes de la Liga

    public static void predeterminados(Setting ajustes){
        ajustes.setNombre("liga");
        ajustes.setEdad(15);
        ajustes.setnEquipos(5);
        ajustes.setnJugadores(25);
        int suplentes = ajustes.getnJugadores()-(2+4+4+4);
        ajustes.setFormacion(new int[]{2, 4, 4, 4,suplentes});
        ajustes.setDerrota(0);
        ajustes.setEmpate(3);
        ajustes.setVictoria(5);
        ajustes.setFecha(1, "Enero");

        System.out.println("Opciones predeterminadas en código");
        System.out.println();
        System.out.print(ajustes);
        Setting.salidaArrayNumNoEnter(ajustes.getFormacion());
        System.out.println();
        System.out.println("-----------------------------------------------------------");
    }

    public static void menuUso(Liga liga, Equipo[] equipos, Calendario calendario, Setting setting){

        Scanner sc = new Scanner(System.in);

        System.out.println("Bienvenido a "+liga.getNombre());
        menuPrincipal();

        int opcion;
        boolean exit = false;

        while (!exit) {
            opcion=leerNumero();
            switch (opcion) {

                case 1: //Caso de querer imprimir toda la Liga
                    System.out.print("Numero de Jornadas Totales: ");
                    int jTotal=calendario.getJornadas().length;
                    System.out.println(jTotal);
                    System.out.println();
                    imprimirClasificacionCompleta(equipos, calendario,setting,jTotal);
                    break;

                case 2: //Caso de querer imprimir hasta una jornada determinada o uns jornada
                    System.out.println("Indique la ultima jornada que desea que se simule");
                    int jFinal=leerNumero();
                    clasificacionParcial(equipos,calendario,setting,jFinal);
                    break;

                case 4: //Caso EXIT
                    exit = true;
                    break;

                default:
                    System.out.println("Eleccion no disponible, intentelo de nuevo");
                    break;
            }
            System.out.println("¿Desea Salir del programan? y/n");
            char salir = sc.next().charAt(0);
            if (salir == 'y' || salir == 'Y') {
                exit = true;
                limpiarPantalla();

            } else {
                exit = false;
                menuPrincipal();
            }
        }
    }

    public static void menuPrincipal(){
        System.out.println();
        System.out.println("Nota: las ligas generadas en ambas opciones comparten equipos y enfrentamientos pero cambian de resultados, pues la simulacion se reinicia");
        System.out.println("¿Que desea hacer?");
        System.out.println();
        System.out.println("1. Generar una liga Completa");
        System.out.println("2. Generar una Liga hasta una jornada");
        System.out.println("4. SALIR");
    }

    public static void configuracion(Setting ajustes) {
        System.out.println();
        System.out.println("Bienvenido al programa de LA LIGA, indique que desea modificar. En caso de querer dejar las predeterminadas, pulse 0: ");
        System.out.println();
        imprimirMenu();
        elegirMenu(ajustes);
        System.out.println();

        System.out.println("Preferencias elegidas.");
        System.out.println();
        System.out.print(ajustes.toString());
        Setting.salidaArrayNumNoEnter(ajustes.getFormacion());
        System.out.println();
        System.out.println();
        System.out.println("Reiniciar programa en caso de equivocacion");

        for(int i=0; i<4; i++){
            System.out.println();
        }
    }

    public static void elegirMenu(Setting ajustes) {
        Scanner sc = new Scanner(System.in);
        int set;
        boolean exit = false;

        while (!exit) {
            set = leerNumero();
            switch (set) {

                case 0:
                    exit = true;
                    break;

                case 1:
                    ajustesBasicos(ajustes);
                    break;

                case 2:
                    composicion(ajustes);
                    break;

                case 3:
                    puntuacion(ajustes);
                    break;

                case 4:
                    fechas(ajustes);
                    break;

                default:
                    System.out.println("Eleccion no disponible, intentelo de nuevo");
                    break;
            }
            System.out.println("¿Desea Salir de la configuración? y/n");
            char salir = sc.next().charAt(0);
            if (salir == 'y' || salir == 'Y') {
                exit = true;
                for(int i=0; i<4; i++){
                    System.out.println();
                }

            } else {
                exit = false;
                imprimirMenu();
            }
        }
    }

    public static void ajustesBasicos(Setting ajustes) {
        System.out.println("Elija el nombre de la Liga: ");
        String nombre = leerEntrada();
        ajustes.setNombre(nombre);

        System.out.println("Elija la edad de los Jugadores: ");
        int edad = leerNumero();
        ajustes.setEdad(edad);

        System.out.println("Elija el numero de Equipos: ");
        int nEquipos = leerNumero();
        ajustes.setnEquipos(nEquipos);

        System.out.println("Elija el numero de Jugadores: ");
        int nJugadores = leerNumero();
        ajustes.setnJugadores(nJugadores);
    }

    public static void composicion(Setting ajustes) {

        int nJugadores=ajustes.getnJugadores();

        if(ajustes.getnJugadores()!=0){
            System.out.println("Numero Porteros: ");
            int porteros = leerNumero();
            System.out.println("Numero Defensas: ");
            int defensas = leerNumero();
            System.out.println("Numero Centrocampistas: ");
            int centro = leerNumero();
            System.out.println("Numero Delanteros: ");
            int delantero = leerNumero();

            int suplente = nJugadores - (porteros + defensas + centro + delantero);

            int[] compos = {porteros, defensas, centro, delantero, suplente};
            ajustes.setFormacion(compos);
        }else{
            System.out.println("No ha introducido el numero de Jugadores. Vaya a la opcion de 'Ajustes Basicos' para establecerlo");
        }

    }

    public static void imprimirMenu() {
        System.out.println("-------------Opciones-----------");
        System.out.println("0. Dejar ajustes Predeterminados");
        System.out.println("1. Ajustes basicos");
        System.out.println("2. Composicion");
        System.out.println("3. Puntuacion");
        System.out.println("4. Fechas");
    }

    public static void fechas(Setting ajustes) {
        int fecha;
        System.out.println("TEMPORADA 2022");
        System.out.println("Dia Inicio: ");
        int dia = leerNumero();
        System.out.println("Mes: ");
        String mes = leerEntrada();
        ajustes.setFecha(dia, mes);
    }

    public static void puntuacion(Setting ajustes) {

        int vict;
        int derr;
        int emp;
        System.out.println("------------------------------------------------------------");
        System.out.println("Derrota: ");
        ajustes.setDerrota(leerNumero());
        System.out.println("Empate: ");
        ajustes.setEmpate(leerNumero());
        System.out.println("Victoria: ");
        ajustes.setVictoria(leerNumero());
    }

    public static void limpiarPantalla() {
        for (int i = 0; i < 150; i++) {
            System.out.println();
        }
        System.out.println("Gracias por usarme");
    }

    public static int leerNumero() {
        Scanner sc = new Scanner(System.in);
        int num;
        num = sc.nextInt();
        return num;
    }

    public static String leerEntrada() {
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

}
